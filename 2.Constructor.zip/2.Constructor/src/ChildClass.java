public class ChildClass extends ParentClass{
	public ChildClass()
	{
		System.out.println("Clild Class");
	}
	public ChildClass(int a)
	{
		super(a);
		System.out.println("Clild Class"+a);
	}
}
