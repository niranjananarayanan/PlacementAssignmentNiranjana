public class ParentClass {
	public ParentClass()
	{
		System.out.println("Parent Class");
	}
	public ParentClass(int a)
	{
		System.out.println("Parent Class"+a);
	}
}
