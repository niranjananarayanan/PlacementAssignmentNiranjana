public class Call {

	public static void main(String[] args) 
	{
		ChildClass cc= new ChildClass();
		ChildClass cc1= new ChildClass(10);
	}
}
