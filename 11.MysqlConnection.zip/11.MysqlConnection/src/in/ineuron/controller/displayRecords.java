package in.ineuron.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import in.ineuron.util.*;

public class displayRecords {

	public static void main(String[] args) {
		
		Connection connection= null;
		ResultSet resultSet=null;

		try 
		{
			String sqlSelectQuery = "select id,name,age,address from student where id = ?";
						
			connection = jdbc.getJdbcConnection();

			PreparedStatement pstmt = null;
			if (connection != null)
			{
				System.out.println(sqlSelectQuery);
				pstmt = connection.prepareStatement(sqlSelectQuery);
			}

			if (pstmt != null)
			{
				Scanner scanner = new Scanner(System.in);		
				System.out.print("Enter the student id :: ");
				int sid = scanner.nextInt();
				pstmt.setInt(1, sid);
			}

			if (pstmt != null) 
				resultSet = pstmt.executeQuery();
				
			if (resultSet != null) 
			{
				if (resultSet.next()) 
					System.out.println(resultSet.getInt(1)+resultSet.getString(2)+resultSet.getInt(3)+resultSet.getString(4));
			}
			else
				System.out.println("No records fount");

		} catch (SQLException | IOException e) {
				e.printStackTrace();
		}
	}
}
