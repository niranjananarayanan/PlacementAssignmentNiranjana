import java.util.Scanner;

public class Calculate {

	public static void main(String[] args) 
	{
		System.out.println("Choose the Shape for which the Area and Perimeter is to be Calculated from our ShapeList");
		System.out.println("Circle");
		System.out.println("Triangle");
		
		String shape;
		Scanner scan= new Scanner(System.in);
		shape=scan.nextLine();
		
		if(shape.equalsIgnoreCase("Circle"))
		{
			double radius;
			System.out.println("Enter the radius of the Circle to be Calculated");
			radius=scan.nextDouble();
			
			Circle c = new Circle(radius);
			System.out.println("Circle - Area: " + c.area());
			System.out.println("Circle - Perimeter: " + c.perimeter());
			System.out.println("Thanks for using the application!!!");
		}else if(shape.equalsIgnoreCase("Triangle"))
		{
			double l, b, h;
			System.out.println("Enter the Length of the Trianle to be Calculated");
			l=scan.nextDouble();
			System.out.println("Enter the Breadth of the Trianle to be Calculated");
			b=scan.nextDouble();
			System.out.println("Enter the Height of the Trianle to be Calculated");
			h=scan.nextDouble();
			
			Triangle t = new Triangle(l, b, h);
			System.out.println("Trianle - Area: " + t.area());
			System.out.println("Trianle - Perimeter: " + t.perimeter());
			System.out.println("Thanks for using the application!!!");
		}else
		{
			System.out.println("Didnt match to our ShapeList");
			System.out.println("Pls Try Again!!!");
		}		
	}

}
