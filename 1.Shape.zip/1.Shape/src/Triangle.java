public class Triangle implements Shape
{
	private double length;
	private double breadth;
	private double height;
	
	public Triangle(double length, double breadth, double height)
	{
		this.length=length;
		this.breadth=breadth;
		this.height=height;
	}

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return (breadth*height)/2;
	}

	@Override
	public double perimeter() {
		// TODO Auto-generated method stub
		return length+breadth+height;
	}
	
}
