public class DefinitionClass extends AbstractClass{
	@Override
	public void action()
	{
		System.out.println("Definition for Abstract method from extended class");
	}
	
	@Override
	public void run() 
	{
		System.out.println("Definition for Abstract method from extended class");
	}
}
