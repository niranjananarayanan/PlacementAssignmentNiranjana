abstract public class AbstractClass implements Interface{
	@Override
	public void action()
	{
		System.out.println("Definition for Abstract method from implemented class");
	}
	public abstract void run();
}
