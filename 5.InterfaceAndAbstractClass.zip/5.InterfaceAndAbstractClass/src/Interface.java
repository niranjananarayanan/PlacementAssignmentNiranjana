public interface Interface {
	void action();
}
