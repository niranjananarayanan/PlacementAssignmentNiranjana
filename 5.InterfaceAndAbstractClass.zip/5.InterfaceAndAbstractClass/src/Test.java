public class Test {

	public static void main(String[] args) 
	{
		//Interface ref= new Interface();-instatiation not possible coz no constructor available
		
		//Interface ref= new AbstractClass();
		
		Interface ref1= new DefinitionClass();
		ref1.action();//only methods of Interface can be accessed not the methods of implementation class
		
		//AbstractClass ref= new AbstractClass();-cannot provide a object reference
			
		DefinitionClass ref2=new DefinitionClass();
		ref2.action();
		ref2.run();
	}
}
