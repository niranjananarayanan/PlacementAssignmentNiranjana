import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Sort {

	public static void main(String[] args) {
		
		List <String> list= new ArrayList<>();
		list.add("Niranjana");
		list.add("Tinku");
		list.add("Narayanan");
		list.add("Vimala");
		list.add("Brindha");
		list.add("Vanaja");
		list.add("Natarajan");
		list.add("Teja");
		list.add("Banu");
		
		Stream<String> stream=list.stream();
		stream.filter((String s)->s.startsWith("N")).sorted().forEach(System.out::println);
	}

}
