package in.ineuron;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import in.ineuron.dto.Student;

public class select {
	
	public static Student searchStudent() {
		Connection connection= null;
		Statement  pstmt   = null;
		ResultSet  resultSet   = null;
		Student   student=null;

		try{	
			 Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url = "jdbc:mysql://localhost:3306/jdbcapp";
			String userName = "root";
			String passWord = "admin";
            connection = DriverManager.getConnection(url,userName,passWord);
	
			String sqlSelectQuery = "select id,name,age,address from student";
			
				pstmt = connection.createStatement();	
				resultSet = pstmt.executeQuery(sqlSelectQuery);
					
				if (resultSet.next()) {
					student = new Student();

					// copy resultSet data to student object
					student.setSid(resultSet.getInt(1));
					student.setSname(resultSet.getString(2));
					student.setSage(resultSet.getInt(3));
					student.setSaddress(resultSet.getString(4));

					return student;
				    }
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		return student;
	}
	
}
