package in.ineuron;




import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import in.ineuron.bo.CoronaVaccine;
import in.ineuron.service.ICoronaVaccineMgmtService;

@SpringBootApplication
public class Q21Application {

	public static void main(String[] args) {
		ApplicationContext factory=	SpringApplication.run(Q21Application.class, args);
		ICoronaVaccineMgmtService service = factory.getBean(ICoronaVaccineMgmtService.class);
		
		
		
		service.fetchAllDetails().forEach(System.out::println);
		
		
		
		  ((ConfigurableApplicationContext) factory).close();
	}
}
