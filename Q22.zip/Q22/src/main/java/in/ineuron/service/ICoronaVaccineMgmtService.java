package in.ineuron.service;



import in.ineuron.bo.CoronaVaccine;

public interface ICoronaVaccineMgmtService {
	public Iterable<CoronaVaccine> fetchAllDetails();

}
