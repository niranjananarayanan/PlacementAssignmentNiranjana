package in.ineuron.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.dao.ITouristRepo;
import in.ineuron.exception.TouristNotFoundException;
import in.ineuron.model.Product;

@Service
public class ProductMgmtServiceImpl implements IProductMgmtService {

	@Autowired
	private ITouristRepo repo;

	@Override
	public String registerProduct(Product product) {
		Integer tid = repo.save(product).getPid();
		return "Tourist is registerd having the ticket id :: " + tid;
	}

	

	@Override
	public Product fetchProductById(Integer pid) {
		return repo.findById(pid)
				.orElseThrow(() -> new TouristNotFoundException("tourist with id :: " + pid + " not found"));
	}

	@Override
	public String updateProductByDetails(Product product) {

		Optional<Product> optional = repo.findById(product.getPid());
		if (optional.isPresent()) {
			repo.save(product); // save() performs both insert and update depends on id value
			return "Tourist with the id ::" + product.getPid() + " updated";
		} else {
			throw new TouristNotFoundException(
					"tourist with the id:: " + product.getPid() + " not available for updation");
		}
	}

	

	@Override
	public String deleteProductById(Integer pid) {
		Optional<Product> optional = repo.findById(pid);
		if (optional.isPresent()) {
			repo.delete(optional.get());
			return "Tourist with the id :: " + pid + " deleted...";
		} else {
			throw new TouristNotFoundException("Tourist not found for the id " + pid);
		}
	}
}
