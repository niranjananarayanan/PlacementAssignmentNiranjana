package in.ineuron.service;

import java.util.List;

import in.ineuron.model.Product;

public interface IProductMgmtService {
	public String registerProduct(Product product);
	public Product fetchProductById(Integer pid);
	public String updateProductByDetails(Product product);
	public String deleteProductById(Integer pid);
	
}
