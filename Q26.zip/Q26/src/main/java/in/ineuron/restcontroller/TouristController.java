package in.ineuron.restcontroller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.model.Product;
import in.ineuron.service.IProductMgmtService;

@RestController
@RequestMapping("/api/product")
public class TouristController {

	@Autowired
	private IProductMgmtService service;

	@PostMapping("/register")
	public ResponseEntity<String> buyProduct(@RequestBody Product product) {
		try {
			String resultMsg = service.registerProduct(product);
			return new ResponseEntity<String>(resultMsg, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<String>("Problem in tourist enrollment", HttpStatus.INTERNAL_SERVER_ERROR);// 500
																													// //
																													// Error
		}
	}

	

	@GetMapping("/find/{pid}")
	public ResponseEntity<?> displayProductById(@PathVariable("pid") Integer pid) {
		try {
			Product product = service.fetchProductById(pid);
			return new ResponseEntity<Product>(product, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	

	@PutMapping("/modify")
	public ResponseEntity<String> modifyproduct(@RequestBody Product product) {
		try {
			String msg = service.updateProductByDetails(product);
			return new ResponseEntity<String>(msg, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/delete/{pid}")
	public ResponseEntity<String> removeProductById(@PathVariable("pid") Integer pid) {
		try {
			String msg = service.deleteProductById(pid);
			return new ResponseEntity<String>(msg, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
}
