package in.ineuron.aspect;

import org.aspectj.lang.JoinPoint;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
 
@Aspect
@Component
public class aspect {
	// Syntax:: AS RT packageName.ClassName.methodName(parameter)
    @Pointcut(value = "execution(* in.ineuron.service.service.*(..))")
    private void
    printLogs()
    {
    }
   
    @Before( "execution(* in.ineuron.service.service.*(..))")
    public void printLogStatementsBefore()
    {
     System.out.println( "Looking for @Around advice, if none is there, @Before will be called first. My role is to execute before each and every method");
    }
  
    
    @After( "execution(* in.ineuron.service.service.*(..))")
    public void printLogStatementsAfter()
    {
        System.out.println("Looking for @Around advice, if none is there, @After will be called after @Before(if available). My role is to execute after each and every method");
    }
 
    
    @AfterReturning( value= "execution(* in.ineuron.service.service.*(..))",returning = "account")
    public void  logsAfterReturningDisplay(JoinPoint joinPoint)
    {
        System.out.println("After Returning method:"  + joinPoint.getSignature());
      
    }
 
   
    @Around(value = "printLogs()")
    public void logsAroundAdvice(ProceedingJoinPoint proJoinPoint)
        throws Throwable
      {
        System.out.println(  "The method aroundAdvice() before invocation of the method " + proJoinPoint.getSignature().getName() + " method");
        try {
            proJoinPoint.proceed();
        }
        finally {
        }
        System.out.println("The method aroundAdvice() after invocation of the method "  + proJoinPoint.getSignature().getName() + " method");
    }
}
