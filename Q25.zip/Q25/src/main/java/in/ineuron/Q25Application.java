package in.ineuron;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import in.ineuron.service.service;

@SpringBootApplication
@EnableAspectJAutoProxy
public class Q25Application {

	public static void main(String[] args) {
		 ConfigurableApplicationContext context = SpringApplication.run(Q25Application.class, args);
		
        service service = context.getBean(service.class);
       
        String employeeNumber = "emp12345";
        try {
            service.employeeStatus(employeeNumber);
        }
        catch (Exception ex) {
            System.out.println("Exception occurred.." + ex.getMessage());
        }
        
       
        String employeeAccountNumber = "Emp1212";
        try {
            service.getAccountBalance( employeeAccountNumber);
        }
        catch (Exception ex) {
            System.out.println("Exception occurred.." + ex.getMessage());
        }
 
        
        int promotionExamMarks = 650;
        try {
            service.eligibilityForPromotion( promotionExamMarks);
        }
        catch (Exception ex) {
            System.out.println("Exception occurred.." + ex.getMessage());
        }
       
        context.close();
	}

}
