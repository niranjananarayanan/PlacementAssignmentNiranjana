package in.ineuron.service;

import org.springframework.stereotype.Service;

@Service
public class service {
    public void
    getAccountBalance(String employeeAccountNumber)
    {     
       if (employeeAccountNumber.equals("Emp1212")) {
            System.out.println("Total balance: ......");
        }
        else {
            System.out.println(
                "Sorry! wrong account number. Please give correct account number to verify");
        }
    }
 
    public String employeeStatus(String employeeNumber)
    {
        String status = null;
        if (employeeNumber.equals("emp12345")) {
            System.out.println(employeeNumber + " is currently active");
            status = "active";
        }
        else {
            System.out.println(employeeNumber + " is currently inactive");
            status = "Inactive";
        }
        return status;
    }
 
    public String
    eligibilityForPromotion(int promotionExamMarks)
    {
        String status = null;
        if (promotionExamMarks >= 650) {
            System.out.println("Eligible for promotion..");
            status = "eligible";
        }
        else {
            System.out.println(
                "Not eligible for promotion..");
            status = "not eligible";
        }
        return status;
    }
}