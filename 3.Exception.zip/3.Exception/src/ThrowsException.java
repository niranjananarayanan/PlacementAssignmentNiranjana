import java.util.Scanner;

public class ThrowsException {
	int age;
	public void setAge(int age) throws MyException
	{
		if(age<0)
			throw new MyException("Age cannot be negative");
		else
			this.age=age;
	}
	
	public static void main(String[] args) throws MyException 
	{
		int value;
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter your age");
		value=scan.nextInt();
		
		ThrowsException age= new ThrowsException();
		age.setAge(value);
	}
}
