import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		int input;
		Scanner x= new Scanner(System.in);
		System.out.println("Enter no of value of the array:");
		input= x.nextInt();
		
		int a[]= new int[input];
		System.out.println("Enter input value");
		for(int k=0; k<a.length; k++)
			a[k]=x.nextInt();
		
		System.out.println("Entered values of array are:");
		for (int k:a)
			System.out.print(k+" ");
		
		System.out.println();
		
		int d=0;
		
		for(int i=0; i<a.length; i++)
		{
			for(int j=1; j<a.length; j++)
			{
				if(a[j]<a[j-1])
				{
					d=a[j];
					a[j]=a[j-1];
					a[j-1]=d;
				}
			}
		}
		
		System.out.println("Sorted array values are");
		for (int k:a)
			System.out.print(k+" ");
		System.out.println();
		
		System.out.println("Enter key to be searched:");
		int key=x.nextInt();
		
		int first = 0;
	    int last=a.length-1; 
	    int mid = (first + last)/2;  
	    
	    while( first <= last )
	    {  
	        if (a[mid] < key)  
	            first = mid + 1;     
	        else if (a[mid] == key)
	        { 
	            System.out.println("Element("+key+") found at index: " + mid);  
	            break;  
	        }else  
	            last = mid - 1;  
	        mid = (first + last)/2;  
	   }  
	   if ( first > last )  
	      System.out.println("Element is not found!");  

	}

}
