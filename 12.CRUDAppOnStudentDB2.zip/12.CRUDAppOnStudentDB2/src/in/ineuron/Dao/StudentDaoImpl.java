package in.ineuron.Dao;

import in.ineuron.Dto.Student;
import jdbc.util;
import java.sql.*;
import java.io.*;

public class StudentDaoImpl implements IStudentDao{
	
	Connection connection=null;
	PreparedStatement psmt=null;
	ResultSet resultSet=null;

	@Override
	public String addStudent(String sname, Integer sage, String saddress) {
		
		String sqlInsertQuery="insert into student(`name`, `age`, `address`) values(?,?,?)";
		try
		{
			connection= jdbc.util.getJdbcConnection();
			if(connection!=null)
				psmt=connection.prepareStatement(sqlInsertQuery);
			if(psmt!=null)
			{
				psmt.setString(1, sname);
				psmt.setInt(2, sage);
				psmt.setString(3,saddress);
				
				int rowAffected=psmt.executeUpdate();
				if(rowAffected==1)
					return "Success";
			}
		}
		catch(SQLException|IOException e)
		{
			e.printStackTrace();
		}
		return "Failed";
	}

	@Override
	public Student searchStudent(Integer sid) {
		String sqlSelectQuery="select id,name,age,address from student where id = ?";
		Student student=null;
		try
		{
			connection= jdbc.util.getJdbcConnection();
			if(connection!=null)
				psmt=connection.prepareStatement(sqlSelectQuery);
			if(psmt!=null)
			{
				psmt.setInt(1, sid);
			}
			if(psmt!=null)
			{
				resultSet=psmt.executeQuery();
			}
			if(resultSet!=null)
			{
				if(resultSet.next())
				{
					student=new Student();
					student.setSid(resultSet.getInt(1));
					student.setSname(resultSet.getString(2));
					student.setSage(resultSet.getInt(3));
					student.setSaddress(resultSet.getString(4));
					return student;
				}
			}
		}
		catch(SQLException|IOException e)
		{
			e.printStackTrace();
		}
		return student;
	}

	@Override
	public String updateStudent(Student student) {
		String sqlUpdateQuery = "update student set name=?,age=?,address=? where id=?";
		
		try
		{
			connection= jdbc.util.getJdbcConnection();
			if(connection!=null)
				psmt=connection.prepareStatement(sqlUpdateQuery);
			if(psmt!=null)
			{
				psmt.setString(1, student.getSname());
				psmt.setInt(2, student.getSage());
				psmt.setString(3, student.getSaddress());
				psmt.setInt(4, student.getSid());
				
				int rowAffected=psmt.executeUpdate();
				if(rowAffected==1)
					return "Success";
			}
		}
		catch(SQLException|IOException e)
		{
			e.printStackTrace();
		}
		return "Failed";
	}

	@Override
	public String deleteStudent(Integer sid) {
		String sqlDeleteQuery="delete from student where id=?;";
		try
		{
			connection= jdbc.util.getJdbcConnection();
			if(connection!=null)
				psmt=connection.prepareStatement(sqlDeleteQuery);
			if(psmt!=null)
			{
				psmt.setInt(1, sid);
				
				int rowAffected=psmt.executeUpdate();
				if(rowAffected==1)
					return "Success";
				else
					return "not found";
			}
		}
		catch(SQLException|IOException e)
		{
			e.printStackTrace();
			return "Failed";
		}
		return "Failed";
	}

}
