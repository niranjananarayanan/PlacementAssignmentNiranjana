package in.ineuron.DaoFactory;
import in.ineuron.Dao.*;
import in.ineuron.Service.IStudentService;
import in.ineuron.Service.StudentServiceImpl;

public class StudentDaoFactory {
	
	private StudentDaoFactory()
	{
		
	}
	
	private static IStudentDao studentDao=null;

	public static IStudentDao getStudentDao() {
		if (studentDao==null)
			studentDao=new StudentDaoImpl();
		return studentDao;
	}

}
