package demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Demo {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Connection connection = jdbc.util.getJdbcConnection();
		if(connection!=null)
			System.out.println("connection not established");		
	}
}
