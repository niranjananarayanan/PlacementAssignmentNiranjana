package jdbc;

import java.io.*;
import java.sql.*;
import java.util.*;

public class util {

	private util()
	{
	
	}

	static 
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
		}
		catch (ClassNotFoundException ce) 
		{
			ce.printStackTrace();
		}
	}

	public static Connection getJdbcConnection() throws SQLException, IOException 
	{
		FileInputStream fis = new FileInputStream("D:\\Niranjana\\CRUDAppOnStudentDB\\Application.properties");
		Properties properties = new Properties();
		properties.load(fis);

		Connection connection = DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("user"), properties.getProperty("password"));
		System.out.println("connection object created...");
		return connection;
	}

			
	public static void cleanUp(Connection con, Statement statement, ResultSet resultSet) throws SQLException 
	{
		if (con != null) 
		{
			con.close();
		}
		if (statement != null) 
		{
			statement.close();
		}
		if (resultSet != null) 
		{
			resultSet.close();
		}

	}
	
}
