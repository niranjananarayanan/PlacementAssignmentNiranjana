package in.ineuron.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.dto.Blog;
import in.ineuron.service.IBlogService;
import in.ineuron.servicefactory.BlogServiceFactory;

@WebServlet("/controller/*")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	private void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		IBlogService BlogService = BlogServiceFactory.getBlogService();

		if (request.getRequestURI().endsWith("addBlog")) {

			String title = request.getParameter("title");
			String description = request.getParameter("description");
			String content = request.getParameter("content");

			Blog blog = new Blog();
			blog.setTitle(title);
			blog.setDescription((description));
			blog.setContent(content);

			String status = BlogService.addBlog(blog);
			RequestDispatcher rd = null;

			if (status.equals("success")) {
				request.setAttribute("status", "success");
				rd = request.getRequestDispatcher("../insertResult.jsp");
				rd.forward(request, response);
			} else {
				request.setAttribute("status", "failure");
				rd = request.getRequestDispatcher("../insertResult.jsp");
				rd.forward(request, response);
			}
		}

		if (request.getRequestURI().endsWith("viewBlog")) {
			

			Blog BLOG = BlogService.viewBlog();
			
			request.setAttribute("BLOG", BLOG);
			RequestDispatcher rd = null;
			rd = request.getRequestDispatcher("../display.jsp");
			rd.forward(request, response);
		}
		
		
	}
}
