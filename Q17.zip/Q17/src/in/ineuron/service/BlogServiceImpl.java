package in.ineuron.service;

import in.ineuron.daofactory.BlogDaoFactory;
import in.ineuron.dto.Blog;
import in.ineuron.dao.IBlogDao;

//service layer logic
public class BlogServiceImpl implements IBlogService {

	private IBlogDao stdDao;

	@Override
	public String addBlog(Blog student) {
		stdDao = BlogDaoFactory.getStudentDao();
		return stdDao.addBlog(student);
	}

	@Override
	public Blog viewBlog() {
		stdDao = BlogDaoFactory.getStudentDao();
		return stdDao.viewBlog();
	}

	

}
