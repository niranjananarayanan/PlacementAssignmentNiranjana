package in.ineuron.service;

import in.ineuron.dto.Blog;

public interface IBlogService {
	
	// operations to be implemented
	public String addBlog(Blog student);

	public Blog viewBlog();


}
