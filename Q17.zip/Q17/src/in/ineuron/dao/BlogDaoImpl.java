package in.ineuron.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import in.ineuron.dto.Blog;
import in.ineuron.util.JdbcUtil;

//Persistence logic using JDBC API
public class BlogDaoImpl implements IBlogDao {

	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet resultSet = null;
	Statement pst = null;

	@Override
	public String addBlog(Blog Blog) {

		String sqlInsertQuery = "insert into blog(title,description,content)values(?,?,?)";
		try {
			connection = JdbcUtil.getJdbcConnection();
			if (connection != null)
				pstmt = connection.prepareStatement(sqlInsertQuery);

			if (pstmt != null) {

				pstmt.setString(1, Blog.getTitle());
				pstmt.setString(2, Blog.getDescription());
				pstmt.setString(3, Blog.getContent());

				int rowAffected = pstmt.executeUpdate();
				if (rowAffected == 1) {
					return "success";
				}
			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

		return "failure";
	}

	@Override
	public Blog viewBlog() {
		String sqlSelectQuery = "select title,description,content from blog";
		Blog blog = null;

		try {
			connection = JdbcUtil.getJdbcConnection();

			if (connection != null)
				pst = connection.createStatement();

		
			if (pstmt != null) {
				resultSet = pstmt.executeQuery(sqlSelectQuery);
			}

			if (resultSet != null) {

				if (resultSet.next()) {
				 blog = new Blog();

					// copy resultSet data to student object
					blog.setTitle(resultSet.getString(1));
					blog.setDescription(resultSet.getString(2));
					blog.setContent(resultSet.getString(3));

					return blog;
				}

			}

		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}

		return blog;
	}
}


