package in.ineuron.dao;

import in.ineuron.dto.Blog;

public interface IBlogDao {
	
	// operations to be implemented
	public String addBlog(Blog student);

	public Blog viewBlog();

	

}
