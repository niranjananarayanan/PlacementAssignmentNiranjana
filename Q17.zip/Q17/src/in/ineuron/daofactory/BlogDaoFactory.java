package in.ineuron.daofactory;

import in.ineuron.dao.IBlogDao;
import in.ineuron.dao.BlogDaoImpl;
public class BlogDaoFactory {

	private BlogDaoFactory() {}

	private static IBlogDao BlogDao = null;

	public static IBlogDao getStudentDao() {
		if (BlogDao == null) {
			BlogDao = new BlogDaoImpl();
		}
		return BlogDao;
	}
}
