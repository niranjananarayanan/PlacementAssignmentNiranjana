import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class SecondLargestAndSecondSmallest {
	
		public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		ArrayList<Integer> numbers=new ArrayList<Integer>();
		System.out.println("Enter numbers");
		while(scan.hasNextInt())	
		{
			numbers.add(scan.nextInt());
		}
		System.out.println(numbers);
		
		int n= numbers.size();
		
		Collections.sort(numbers);
		
		System.out.println("Second Largest is:"+ numbers.get(n-2));
		
		System.out.println("Second Smallest is:" +numbers.get(1));
	}
}
